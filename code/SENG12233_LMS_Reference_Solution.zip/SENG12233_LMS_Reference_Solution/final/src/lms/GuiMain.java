package lms;

import lms.dao.*;
import lms.model.*;
import lms.service.Library;
import lms.service.LibraryController;
import lms.ui.MainFrame;

import javax.swing.*;

/** Week 11 start-up: database -> model -> controller -> view. */
public class GuiMain {
    public static void main(String[] args) {
        Database.init();                                  // create tables if needed

        ItemDAO itemDAO = new ItemDAO();
        MemberDAO memberDAO = new MemberDAO();
        LoanDAO loanDAO = new LoanDAO();
        seedIfEmpty(itemDAO, memberDAO);                  // first run only

        Library library = new Library();                  // MODEL
        LibraryController controller =                    // CONTROLLER
                new LibraryController(library, itemDAO, memberDAO, loanDAO);
        controller.loadFromDatabase();

        SwingUtilities.invokeLater(() -> new MainFrame(controller).setVisible(true));   // VIEW
    }

    private static void seedIfEmpty(ItemDAO itemDAO, MemberDAO memberDAO) {
        if (itemDAO.findAll().isEmpty()) {
            itemDAO.insert(new Book("B001", "Clean Code", "Robert C. Martin"));
            itemDAO.insert(new Book("B002", "Refactoring", "Martin Fowler"));
            itemDAO.insert(new DVD("D001", "Introduction to Algorithms", 120));
            itemDAO.insert(new Magazine("G001", "Software Weekly", 42));
        }
        if (memberDAO.findAll().isEmpty()) {
            memberDAO.insert(new Student("M001", "Nadeesha Perera"));
            memberDAO.insert(new Staff("M002", "Mr. Kasun Silva"));
        }
    }
}
