package lms.service;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Repository<T> - a GENERIC class (Week 10).
 *
 * T is a type parameter: "some type, decided by whoever uses me".
 *   Repository<LibraryItem>  stores items
 *   Repository<Member>       stores members
 * One class, written once, type-safe for both. No casts needed.
 *
 * Inside, a Map gives O(1) lookup by id (a List would have to scan).
 * The Function<T,String> tells the repository how to get an id out of a T.
 */
public class Repository<T> {

    private final Map<String, T> store = new LinkedHashMap<>();   // keeps insertion order
    private final Function<T, String> idOf;

    public Repository(Function<T, String> idOf) {
        this.idOf = idOf;
    }

    public void add(T entity) {
        String id = idOf.apply(entity);
        if (store.containsKey(id)) {
            throw new IllegalArgumentException("An entry with id '" + id + "' already exists");
        }
        store.put(id, entity);
    }

    /** Optional says honestly: the answer might be "nothing". */
    public Optional<T> findById(String id) {
        return Optional.ofNullable(store.get(id));
    }

    public boolean exists(String id) { return store.containsKey(id); }

    public List<T> findAll() { return new ArrayList<>(store.values()); }

    /** Streams: describe WHAT you want (filter), not HOW to loop. */
    public List<T> search(Predicate<T> condition) {
        return store.values().stream().filter(condition).toList();
    }

    public int size() { return store.size(); }
}
