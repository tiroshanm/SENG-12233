package lms.service;

import lms.dao.ItemDAO;
import lms.dao.LoanDAO;
import lms.dao.MemberDAO;
import lms.exception.ItemNotAvailableException;
import lms.model.*;

import java.util.List;

/**
 * LibraryController - the C in MVC (Week 9); now also talks to the DAOs (Week 11).
 *
 *   Model      = lms.model + Library   (data and rules; knows nothing about windows)
 *   View       = lms.ui.MainFrame      (windows; knows nothing about the rules)
 *   Controller = this class            (receives what the user typed, calls the model)
 *
 * The view never touches Book/DVD/Library directly. It asks the controller.
 * That is what lets us swap the console for Swing - and later swap the
 * in-memory list for a database - without rewriting the other layers.
 */
public class LibraryController {

    private final Library library;
    private final ItemDAO itemDAO;
    private final MemberDAO memberDAO;
    private final LoanDAO loanDAO;

    public LibraryController(Library library, ItemDAO itemDAO, MemberDAO memberDAO, LoanDAO loanDAO) {
        this.library = library;
        this.itemDAO = itemDAO;
        this.memberDAO = memberDAO;
        this.loanDAO = loanDAO;
    }

    /** Start-up: rebuild the in-memory model from the database. */
    public void loadFromDatabase() {
        for (LibraryItem item : itemDAO.findAll()) library.addItem(item);
        for (Member m : memberDAO.findAll()) library.addMember(m);
        for (LoanDAO.OpenLoan loan : loanDAO.findOpenLoans()) {
            try {
                library.borrowItem(loan.itemId(), loan.memberId());   // replays the loan through the model's rules
            } catch (ItemNotAvailableException e) {
                throw new IllegalStateException("Database holds an impossible loan: " + loan, e);
            }
        }
    }

    /** Order matters: validate (construct) -> save to DB -> add to memory. */
    public synchronized void addItem(String type, String id, String title, String detail) {
        if (library.hasItem(id)) {
            throw new IllegalArgumentException("An item with id '" + id + "' already exists");
        }
        LibraryItem item = switch (type) {
            case "Book" -> new Book(id, title, detail);
            case "DVD" -> new DVD(id, title, parseWholeNumber(detail, "Duration"));
            case "Magazine" -> new Magazine(id, title, parseWholeNumber(detail, "Issue number"));
            default -> throw new IllegalArgumentException("Unknown item type: " + type);
        };
        itemDAO.insert(item);
        library.addItem(item);
    }

    public synchronized void addMember(String type, String id, String name) {
        if (library.getMembers().stream().anyMatch(m -> m.getMemberId().equals(id))) {
            throw new IllegalArgumentException("A member with id '" + id + "' already exists");
        }
        Member member = "Staff".equals(type) ? new Staff(id, name) : new Student(id, name);
        memberDAO.insert(member);
        library.addMember(member);
    }

    public synchronized void borrow(String itemId, String memberId) throws ItemNotAvailableException {
        library.borrowItem(itemId, memberId);          // rules first
        try {
            loanDAO.recordLoan(itemId, memberId);      // then persist
        } catch (RuntimeException e) {
            library.returnItem(itemId);                // undo the in-memory change
            throw e;
        }
    }

    public synchronized void giveBack(String itemId) throws ItemNotAvailableException {
        library.returnItem(itemId);
        loanDAO.recordReturn(itemId);
    }

    /** Read-only DB query: safe to call from a background thread. */
    public int countOverdue() { return loanDAO.countOverdue(loanDays()); }

    public static int loanDays() { return Integer.getInteger("lms.loan.days", 14); }

    public List<String[]> loanHistory() { return loanDAO.history(); }

    public List<LibraryItem> getItems() { return library.getItems(); }

    /** An empty search box means "show everything". */
    public List<LibraryItem> search(String text) {
        return (text == null || text.isBlank()) ? library.getItems() : library.search(text);
    }

    /** Plain-text report for a dialog. */
    public String loanReport() {
        var counts = library.loansPerMember();
        if (counts.isEmpty()) return "No items are currently on loan.";
        StringBuilder sb = new StringBuilder("Items currently on loan:\n");
        counts.forEach((name, n) -> sb.append("  ").append(name).append(": ").append(n).append('\n'));
        sb.append("\nAvailable: ").append(library.availableItems().size());
        return sb.toString();
    }
    public List<Member> getMembers() { return library.getMembers(); }

    private int parseWholeNumber(String text, String label) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(label + " must be a whole number");
        }
    }
}
