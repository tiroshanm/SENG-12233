package lms.service;

import java.util.function.IntConsumer;

/**
 * OverdueChecker - a background DAEMON thread (Week 12).
 *
 * Every few seconds it asks the database how many loans are overdue and
 * hands the number to a callback. It never touches Swing itself: the
 * callback is responsible for jumping onto the Event Dispatch Thread.
 *
 * Daemon = "do not keep the program alive just for me": when the window
 * closes and the main work ends, the JVM exits even though this loop
 * would run forever.
 */
public class OverdueChecker implements Runnable {

    private final LibraryController controller;
    private final IntConsumer onResult;
    private final long intervalMillis;

    public OverdueChecker(LibraryController controller, long intervalMillis, IntConsumer onResult) {
        this.controller = controller;
        this.intervalMillis = intervalMillis;
        this.onResult = onResult;
    }

    /** Creates, configures and starts the thread. */
    public static Thread start(LibraryController controller, long intervalMillis, IntConsumer onResult) {
        Thread t = new Thread(new OverdueChecker(controller, intervalMillis, onResult), "overdue-checker");
        t.setDaemon(true);
        t.start();
        return t;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                onResult.accept(controller.countOverdue());
                Thread.sleep(intervalMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();          // restore the flag and leave the loop
            } catch (RuntimeException e) {
                System.err.println("Overdue check failed: " + e.getMessage());   // keep the thread alive
                try { Thread.sleep(intervalMillis); } catch (InterruptedException ie) { return; }
            }
        }
    }
}
