package lms.service;

import lms.exception.ItemNotAvailableException;
import lms.exception.MemberNotFoundException;
import lms.model.Book;
import lms.model.DVD;
import lms.model.LibraryItem;
import lms.model.Loanable;
import lms.model.Member;
import lms.model.Reservable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Library - Week 12 version: every method that touches the shared data is
 * SYNCHRONIZED, because the GUI thread and background threads now share it.
 * (Week 10: Generics, Collections, Streams.)
 *
 * Kept from Week 3: printAllLateFees(), the addItem() overloads.
 * New this week: methods that talk to INTERFACE types (Loanable,
 * Reservable) instead of concrete classes, and a Comparable-based sort.
 */
public class Library {

    // Week 10: Lists replaced by generic Repositories (Maps inside)
    private final Repository<LibraryItem> items = new Repository<>(LibraryItem::getId);
    private final Repository<Member> members = new Repository<>(Member::getMemberId);

    // ---- from Week 3 (unchanged) ----

    public synchronized void addItem(LibraryItem item) {
        items.add(item);
    }

    public synchronized void addItem(Book book) {
        items.add(book);
    }

    public synchronized void addItem(DVD dvd) {
        items.add(dvd);
    }

    public synchronized void addMember(Member member) { members.add(member); }

    /** True if an item with this id already exists (used to reject duplicates). */
    public synchronized boolean hasItem(String itemId) {
        return items.exists(itemId);
    }

    public synchronized void printAllLateFees(int daysLate) {
        System.out.println("--- Late fees if " + daysLate + " day(s) late ---");
        for (LibraryItem item : items.findAll()) {
            System.out.println(item.getTitle() + ": " + item.calculateLateFee(daysLate));
        }
    }

    // ---- NEW in Week 4 ----

    /**
     * The parameter type is the INTERFACE Loanable, not LibraryItem.
     * This method would work for anything that promises to be loanable,
     * even a class that is not a LibraryItem at all.
     */
    public synchronized void lend(Loanable thing, Member member) throws ItemNotAvailableException {
        thing.loan(member);
    }

    // ---- NEW in Week 5 ----

    /** Looks a member up by id. Throws the UNCHECKED MemberNotFoundException. */
    public synchronized Member findMember(String memberId) {
        return members.findById(memberId).orElseThrow(() -> new MemberNotFoundException(memberId));
    }

    /** Looks an item up by id. Throws the CHECKED ItemNotAvailableException. */
    public synchronized LibraryItem findItem(String itemId) throws ItemNotAvailableException {
        Optional<LibraryItem> found = items.findById(itemId);
        if (found.isEmpty()) throw new ItemNotAvailableException("No item with id '" + itemId + "'");
        return found.get();
    }

    /** The one-stop "borrow" operation the GUI will call later. */
    public synchronized void borrowItem(String itemId, String memberId) throws ItemNotAvailableException {
        Member member = findMember(memberId);
        LibraryItem item = findItem(itemId);
        item.loan(member);
    }

    public synchronized void returnItem(String itemId) throws ItemNotAvailableException {
        findItem(itemId).returnItem();
    }

    /**
     * Only some items are Reservable. Checking for the INTERFACE (not for
     * Book) means a future Reservable class works here with no changes.
     */
    public void reserveIfPossible(LibraryItem item, Member member) {
        if (item instanceof Reservable r) {
            r.reserve(member);
        } else {
            System.out.println(item.getTitle() + " cannot be reserved.");
        }
    }

    /** Prints members ranked by activity, using Member's compareTo(). */
    public synchronized void printMembersByActivity() {
        List<Member> sorted = members.findAll();
        Collections.sort(sorted);
        System.out.println("--- Members ranked by activity ---");
        for (Member m : sorted) {
            System.out.println(m.getName() + " (" + m.getBorrowedCount() + " borrowed)");
        }
    }

    public synchronized void listItems() {
        System.out.println("--- Items in the library ---");
        for (LibraryItem item : items.findAll()) System.out.println(item);
    }

    public synchronized void listMembers() {
        System.out.println("--- Registered members ---");
        for (Member m : members.findAll()) System.out.println(m);
    }

    public synchronized List<LibraryItem> getItems() { return items.findAll(); }
    public synchronized List<Member> getMembers() { return members.findAll(); }

    // ---- NEW in Week 10: streams ----

    /** Case-insensitive search in title, id, or author (for books). */
    public synchronized List<LibraryItem> search(String text) {
        String q = text.trim().toLowerCase();
        return items.search(i -> i.getTitle().toLowerCase().contains(q)
                || i.getId().toLowerCase().contains(q)
                || (i instanceof Book b && b.getAuthor().toLowerCase().contains(q)));
    }

    /** Map: member name -> number of items currently on loan. */
    public synchronized Map<String, Long> loansPerMember() {
        return items.findAll().stream()
                .filter(LibraryItem::isBorrowed)
                .collect(Collectors.groupingBy(i -> i.getBorrower().getName(), TreeMap::new, Collectors.counting()));
    }

    /** All items that are currently available, sorted by title. */
    public synchronized List<LibraryItem> availableItems() {
        return items.findAll().stream()
                .filter(i -> !i.isBorrowed())
                .sorted(Comparator.comparing(LibraryItem::getTitle))
                .toList();
    }
}
