package lms.dao;

import lms.exception.DataAccessException;
import lms.model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ItemDAO - Data Access Object for items (Week 11).
 *
 * A DAO hides ALL the SQL for one kind of thing. Nothing outside lms.dao
 * writes SQL. It maps between rows and OBJECTS: the "type" column decides
 * whether a row becomes a Book, a DVD or a Magazine.
 */
public class ItemDAO {

    public void insert(LibraryItem item) {
        String sql = "INSERT INTO items (id, type, title, detail) VALUES (?, ?, ?, ?)";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, item.getId());
            ps.setString(2, item.getClass().getSimpleName());
            ps.setString(3, item.getTitle());
            ps.setString(4, detailOf(item));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not save item " + item.getId(), e);
        }
    }

    public List<LibraryItem> findAll() {
        String sql = "SELECT id, type, title, detail FROM items ORDER BY id";
        List<LibraryItem> result = new ArrayList<>();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                result.add(toItem(rs.getString("id"), rs.getString("type"),
                        rs.getString("title"), rs.getString("detail")));
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not read items", e);
        }
        return result;
    }

    /** Row -> object. This is the "factory" step. */
    private LibraryItem toItem(String id, String type, String title, String detail) {
        return switch (type) {
            case "Book" -> new Book(id, title, detail);
            case "DVD" -> new DVD(id, title, Integer.parseInt(detail));
            case "Magazine" -> new Magazine(id, title, Integer.parseInt(detail));
            default -> throw new DataAccessException("Unknown item type in database: " + type, null);
        };
    }

    /** Object -> the single "detail" column. */
    private String detailOf(LibraryItem item) {
        if (item instanceof Book b) return b.getAuthor();
        if (item instanceof DVD d) return String.valueOf(d.getDurationMinutes());
        if (item instanceof Magazine m) return String.valueOf(m.getIssueNumber());
        return "";
    }
}
