package lms.dao;

import lms.exception.DataAccessException;
import lms.model.Member;
import lms.model.Staff;
import lms.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** MemberDAO - all SQL for the members table (Week 11). */
public class MemberDAO {

    public void insert(Member member) {
        String sql = "INSERT INTO members (id, name, type) VALUES (?, ?, ?)";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, member.getMemberId());
            ps.setString(2, member.getName());
            ps.setString(3, member instanceof Staff ? "STAFF" : "STUDENT");
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not save member " + member.getMemberId(), e);
        }
    }

    public List<Member> findAll() {
        String sql = "SELECT id, name, type FROM members ORDER BY id";
        List<Member> result = new ArrayList<>();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                result.add("STAFF".equals(rs.getString("type")) ? new Staff(id, name) : new Student(id, name));
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not read members", e);
        }
        return result;
    }
}
