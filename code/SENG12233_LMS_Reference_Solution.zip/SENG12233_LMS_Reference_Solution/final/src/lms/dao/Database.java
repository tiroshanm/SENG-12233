package lms.dao;

import lms.exception.DataAccessException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Database - the ONE place that knows how to reach the database (Week 11).
 *
 * Default is SQLite: a single file "lms.db" next to the program. No server
 * to install. The URL can be overridden with  -Dlms.db.url=...  which is how
 * the tests use a throw-away in-memory database.
 *
 * Tables:
 *   items   (id PK, type, title, detail)
 *   members (id PK, name, type)
 *   loans   (item_id FK, member_id FK, borrowed_at, returned_at NULL until returned)
 */
public final class Database {

    public static final String DEFAULT_URL = "jdbc:sqlite:lms.db";

    private Database() { }

    public static String url() {
        return System.getProperty("lms.db.url", DEFAULT_URL);
    }

    /** Opens a NEW connection. Callers close it with try-with-resources. */
    public static Connection getConnection() throws SQLException {
        Connection con = DriverManager.getConnection(url());
        if (url().startsWith("jdbc:sqlite:")) {
            // SQLite ignores foreign keys unless you switch them on per connection.
            try (Statement st = con.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
            }
        }
        return con;
    }

    /** Creates the tables if they do not exist yet. Safe to call every start-up. */
    public static void init() {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS items ("
                + " id VARCHAR(20) PRIMARY KEY,"
                + " type VARCHAR(10) NOT NULL,"
                + " title VARCHAR(200) NOT NULL,"
                + " detail VARCHAR(200) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS members ("
                + " id VARCHAR(20) PRIMARY KEY,"
                + " name VARCHAR(100) NOT NULL,"
                + " type VARCHAR(10) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS loans ("
                + " item_id VARCHAR(20) NOT NULL,"
                + " member_id VARCHAR(20) NOT NULL,"
                + " borrowed_at VARCHAR(30) NOT NULL,"
                + " returned_at VARCHAR(30),"
                + " PRIMARY KEY (item_id, borrowed_at),"
                + " FOREIGN KEY (item_id) REFERENCES items(id),"
                + " FOREIGN KEY (member_id) REFERENCES members(id))"
        };
        try (Connection con = getConnection(); Statement st = con.createStatement()) {
            for (String sql : ddl) st.execute(sql);
        } catch (SQLException e) {
            throw new DataAccessException("Could not create the database tables", e);
        }
    }
}
