package lms.dao;

import lms.exception.DataAccessException;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * LoanDAO - all SQL for the loans table (Week 11).
 *
 * A loan row with returned_at = NULL means "still on loan".
 * There is no separate "is borrowed" column to keep in sync - the loans
 * table IS the truth.
 */
public class LoanDAO {

    /** A small immutable data holder (a Java record). */
    public record OpenLoan(String itemId, String memberId) { }

    public void recordLoan(String itemId, String memberId) {
        String sql = "INSERT INTO loans (item_id, member_id, borrowed_at) VALUES (?, ?, ?)";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, itemId);
            ps.setString(2, memberId);
            ps.setString(3, LocalDateTime.now().withNano(0).toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not record the loan of " + itemId, e);
        }
    }

    public void recordReturn(String itemId) {
        String sql = "UPDATE loans SET returned_at = ? WHERE item_id = ? AND returned_at IS NULL";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, LocalDateTime.now().withNano(0).toString());
            ps.setString(2, itemId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not record the return of " + itemId, e);
        }
    }

    /** Used at start-up to restore "who has what". */
    public List<OpenLoan> findOpenLoans() {
        String sql = "SELECT item_id, member_id FROM loans WHERE returned_at IS NULL";
        List<OpenLoan> result = new ArrayList<>();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) result.add(new OpenLoan(rs.getString(1), rs.getString(2)));
        } catch (SQLException e) {
            throw new DataAccessException("Could not read open loans", e);
        }
        return result;
    }

    /** Loans still out that were borrowed more than {@code days} days ago (ISO strings sort correctly). */
    public int countOverdue(int days) {
        String sql = "SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND borrowed_at < ?";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, LocalDateTime.now().minusDays(days).toString());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not count overdue loans", e);
        }
    }

    /** A JOIN across three tables: rows of {borrowed, item title, member name, returned}. */
    public List<String[]> history() {
        String sql = "SELECT l.borrowed_at, i.title, m.name, l.returned_at "
                   + "FROM loans l "
                   + "JOIN items i ON i.id = l.item_id "
                   + "JOIN members m ON m.id = l.member_id "
                   + "ORDER BY l.borrowed_at DESC";
        List<String[]> rows = new ArrayList<>();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String returned = rs.getString(4);
                rows.add(new String[]{rs.getString(1).replace('T', ' '), rs.getString(2), rs.getString(3),
                        returned == null ? "(on loan)" : returned.replace('T', ' ')});
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not read loan history", e);
        }
        return rows;
    }
}
