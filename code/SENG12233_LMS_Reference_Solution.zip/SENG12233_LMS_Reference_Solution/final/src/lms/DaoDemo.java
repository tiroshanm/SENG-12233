package lms;

import lms.dao.*;
import lms.model.*;

/**
 * DaoDemo - test your DAOs from the console BEFORE touching the GUI.
 * If a DAO is wrong, you want to find out here, not behind a button.
 */
public class DaoDemo {
    public static void main(String[] args) {
        Database.init();
        ItemDAO items = new ItemDAO();
        MemberDAO members = new MemberDAO();
        LoanDAO loans = new LoanDAO();

        items.insert(new Book("B100", "Head First Java", "Kathy Sierra"));
        items.insert(new DVD("D100", "Databases 101", 90));
        members.insert(new Student("M100", "Amal Fernando"));

        System.out.println("--- items in the database ---");
        items.findAll().forEach(System.out::println);
        System.out.println("--- members in the database ---");
        members.findAll().forEach(System.out::println);

        loans.recordLoan("B100", "M100");
        System.out.println("--- open loans ---");
        loans.findOpenLoans().forEach(System.out::println);

        loans.recordReturn("B100");
        System.out.println("--- open loans after return: " + loans.findOpenLoans().size());

        System.out.println("--- history (JOIN) ---");
        for (String[] row : loans.history()) System.out.println(String.join(" | ", row));

        System.out.println("--- foreign key check: loan for a member that does not exist ---");
        try {
            loans.recordLoan("B100", "M999");
        } catch (lms.exception.DataAccessException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
