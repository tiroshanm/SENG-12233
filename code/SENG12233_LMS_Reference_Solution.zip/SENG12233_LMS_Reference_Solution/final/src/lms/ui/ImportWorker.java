package lms.ui;

import lms.service.LibraryController;

import javax.swing.*;
import java.util.List;

/**
 * ImportWorker - a SwingWorker (Week 12).
 *
 * The rule of Swing threading:
 *   - SLOW work must NOT run on the Event Dispatch Thread (the window freezes).
 *   - Swing components may ONLY be touched ON the Event Dispatch Thread.
 *
 * SwingWorker gives us both:
 *   doInBackground()  runs on a worker thread  -> slow work goes here
 *   publish()/process()/done() run on the EDT   -> safe to update the GUI
 */
public class ImportWorker extends SwingWorker<Integer, Integer> {

    private static final String[][] SAMPLE = {
        {"Design Patterns", "Erich Gamma"}, {"The Pragmatic Programmer", "Andrew Hunt"},
        {"Code Complete", "Steve McConnell"}, {"Java Concurrency in Practice", "Brian Goetz"},
        {"Domain-Driven Design", "Eric Evans"}, {"Clean Architecture", "Robert C. Martin"},
        {"Head First Design Patterns", "Eric Freeman"}, {"Algorithms", "Robert Sedgewick"},
        {"Operating System Concepts", "Abraham Silberschatz"}, {"Database System Concepts", "Abraham Silberschatz"},
    };

    private final LibraryController controller;
    private final JProgressBar bar;
    private final Runnable whenFinished;

    public ImportWorker(LibraryController controller, JProgressBar bar, Runnable whenFinished) {
        this.controller = controller;
        this.bar = bar;
        this.whenFinished = whenFinished;
    }

    @Override
    protected Integer doInBackground() throws Exception {      // WORKER thread
        int added = 0;
        for (int i = 0; i < SAMPLE.length; i++) {
            String id = "I" + String.format("%03d", i + 1);
            try {
                controller.addItem("Book", id, SAMPLE[i][0], SAMPLE[i][1]);
                added++;
            } catch (IllegalArgumentException alreadyThere) {
                // imported before - skip it
            }
            Thread.sleep(400);                                  // pretend this is slow (network / big file)
            publish((i + 1) * 100 / SAMPLE.length);
        }
        return added;
    }

    @Override
    protected void process(List<Integer> chunks) {             // EDT
        bar.setValue(chunks.get(chunks.size() - 1));
    }

    @Override
    protected void done() {                                     // EDT
        try {
            int added = get();
            bar.setString("Imported " + added + " book(s)");
        } catch (Exception e) {
            bar.setString("Import failed");
        }
        whenFinished.run();
    }
}
