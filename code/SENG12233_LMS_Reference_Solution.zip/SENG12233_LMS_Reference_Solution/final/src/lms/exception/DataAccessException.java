package lms.exception;

/**
 * UNCHECKED wrapper for java.sql.SQLException (Week 11).
 *
 * SQLException is a low-level, checked, database-specific exception. If it
 * leaked up to the GUI, every layer would need to know about SQL. Instead
 * the DAO catches it and rethrows this one, with a friendly message.
 */
public class DataAccessException extends RuntimeException {
    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
