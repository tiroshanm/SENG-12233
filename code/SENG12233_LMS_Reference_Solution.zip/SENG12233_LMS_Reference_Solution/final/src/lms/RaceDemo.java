package lms;

/**
 * RaceDemo - see a race condition with your own eyes (Week 12, console).
 *
 * Two threads each add 1 to a shared counter 200,000 times.
 *   unsafe:   count++ is THREE steps (read, add, write) - threads overwrite each other
 *   safe:     synchronized makes the three steps happen as one
 */
public class RaceDemo {
    static volatile int unsafeCount = 0;   // volatile: still NOT atomic
    static int safeCount = 0;
    static synchronized void safeIncrement() { safeCount++; }

    public static void main(String[] args) throws InterruptedException {
        Runnable unsafe = () -> { for (int i = 0; i < 1_000_000; i++) unsafeCount++; };
        Runnable safe = () -> { for (int i = 0; i < 1_000_000; i++) safeIncrement(); };

        run(unsafe);
        run(safe);
        System.out.println("Expected      : 2000000");
        System.out.println("Unsynchronized: " + unsafeCount + (unsafeCount == 2000000 ? "  (lucky run!)" : "  <-- updates were lost"));
        System.out.println("Synchronized  : " + safeCount);
    }

    private static void run(Runnable task) throws InterruptedException {
        Thread a = new Thread(task), b = new Thread(task);
        a.start(); b.start();
        a.join(); b.join();
    }
}
