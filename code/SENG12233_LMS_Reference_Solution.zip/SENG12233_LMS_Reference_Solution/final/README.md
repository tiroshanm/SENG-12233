# Library Management System (SENG 12233)

A desktop Library Management System written in Java 21 with Swing and SQLite.

## Features
- Catalogue of Books, DVDs and Magazines (inheritance, abstract class, interfaces)
- Members: Students (3 items) and Staff (10 items)
- Borrow / return with clear error messages (custom exceptions)
- Search, loan report (generics + streams)
- Everything is saved in `lms.db` (JDBC, DAO pattern)
- Background import with a progress bar; overdue checker thread

## Run
**With Maven**
```bash
mvn package
java -jar target/lms-1.0-shaded.jar
```
**Without Maven** (download `sqlite-jdbc-3.46.0.0.jar` into `lib/` first)
```bash
./build.sh
java -jar build/lms.jar
```

## Architecture
```
lms.model    - Book, DVD, Magazine, Member, ...   (MODEL)
lms.ui       - MainFrame, ImportWorker            (VIEW)
lms.service  - LibraryController, Library, ...    (CONTROLLER + business rules)
lms.dao      - Database, ItemDAO, MemberDAO, LoanDAO
lms.exception- ItemNotAvailableException, MemberNotFoundException, DataAccessException
```

## Author
<your name> - <your index number>
