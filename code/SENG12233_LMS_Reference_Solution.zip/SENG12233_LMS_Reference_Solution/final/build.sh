#!/usr/bin/env bash
# Builds lms.jar without Maven. Needs JDK 17+ and lib/sqlite-jdbc-*.jar
set -e
rm -rf build && mkdir -p build/classes
javac -d build/classes $(find src -name "*.java")
printf 'Main-Class: lms.GuiMain\nClass-Path: lib/sqlite-jdbc.jar\n' > build/manifest.txt
jar cfm build/lms.jar build/manifest.txt -C build/classes .
echo "Built build/lms.jar"
echo "Run with:  java -jar build/lms.jar   (keep a copy of the driver at build/lib/sqlite-jdbc.jar)"
mkdir -p build/lib && cp lib/sqlite-jdbc-*.jar build/lib/sqlite-jdbc.jar 2>/dev/null || echo "WARNING: put sqlite-jdbc-*.jar in lib/ first"
