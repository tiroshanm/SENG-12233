# SENG 12233 - Reference Solution: Week 8

**Lab 5 - GUI I (Swing layouts and widgets)**

`lms.ui.MainFrame` built from BorderLayout + GridLayout + FlowLayout, a JTable, a form and buttons. Buttons do nothing yet.

**Files that changed this week:** `ui/MainFrame`, `GuiMain`

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.GuiMain
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
