package lms;

import lms.model.*;
import lms.service.Library;
import lms.ui.MainFrame;

import javax.swing.*;

/** Starts the window. Swing code must run on the Event Dispatch Thread. */
public class GuiMain {
    public static void main(String[] args) {
        Library library = new Library();
        library.addItem(new Book("B001", "Clean Code", "Robert C. Martin"));
        library.addItem(new Book("B002", "Refactoring", "Martin Fowler"));
        library.addItem(new DVD("D001", "Introduction to Algorithms", 120));
        library.addItem(new Magazine("G001", "Software Weekly", 42));
        library.addMember(new Student("M001", "Nadeesha Perera"));
        library.addMember(new Staff("M002", "Mr. Kasun Silva"));

        SwingUtilities.invokeLater(() -> new MainFrame(library).setVisible(true));
    }
}
