# SENG 12233 - Reference Solution: Week 10

**Lab 7 - Generics, Collections, Streams**

Generic `Repository<T>` backed by a Map. Stream-based `search`, `loansPerMember`, `availableItems`. Search box and Loan Report in the GUI.

**Files that changed this week:** `service/Repository`, `Library`, `LibraryController`, `ui/MainFrame`

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.GuiMain
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
