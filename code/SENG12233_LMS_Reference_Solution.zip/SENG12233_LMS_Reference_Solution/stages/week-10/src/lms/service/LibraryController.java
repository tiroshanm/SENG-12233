package lms.service;

import lms.exception.ItemNotAvailableException;
import lms.model.*;

import java.util.List;

/**
 * LibraryController - the C in MVC (Week 9).
 *
 *   Model      = lms.model + Library   (data and rules; knows nothing about windows)
 *   View       = lms.ui.MainFrame      (windows; knows nothing about the rules)
 *   Controller = this class            (receives what the user typed, calls the model)
 *
 * The view never touches Book/DVD/Library directly. It asks the controller.
 * That is what lets us swap the console for Swing - and later swap the
 * in-memory list for a database - without rewriting the other layers.
 */
public class LibraryController {

    private final Library library;

    public LibraryController(Library library) {
        this.library = library;
    }

    /** Builds the right kind of item from raw text. Throws IllegalArgumentException on bad input. */
    public void addItem(String type, String id, String title, String detail) {
        if (library.hasItem(id)) {
            throw new IllegalArgumentException("An item with id '" + id + "' already exists");
        }
        switch (type) {
            case "Book" -> library.addItem(new Book(id, title, detail));
            case "DVD" -> library.addItem(new DVD(id, title, parseWholeNumber(detail, "Duration")));
            case "Magazine" -> library.addItem(new Magazine(id, title, parseWholeNumber(detail, "Issue number")));
            default -> throw new IllegalArgumentException("Unknown item type: " + type);
        }
    }

    public void borrow(String itemId, String memberId) throws ItemNotAvailableException {
        library.borrowItem(itemId, memberId);
    }

    public void giveBack(String itemId) throws ItemNotAvailableException {
        library.returnItem(itemId);
    }

    public List<LibraryItem> getItems() { return library.getItems(); }

    /** An empty search box means "show everything". */
    public List<LibraryItem> search(String text) {
        return (text == null || text.isBlank()) ? library.getItems() : library.search(text);
    }

    /** Plain-text report for a dialog. */
    public String loanReport() {
        var counts = library.loansPerMember();
        if (counts.isEmpty()) return "No items are currently on loan.";
        StringBuilder sb = new StringBuilder("Items currently on loan:\n");
        counts.forEach((name, n) -> sb.append("  ").append(name).append(": ").append(n).append('\n'));
        sb.append("\nAvailable: ").append(library.availableItems().size());
        return sb.toString();
    }
    public List<Member> getMembers() { return library.getMembers(); }

    private int parseWholeNumber(String text, String label) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(label + " must be a whole number");
        }
    }
}
