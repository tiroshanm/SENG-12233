# SENG 12233 - Sample Project: Week 4

**Lab 3 - Abstract Classes & Interfaces**

Builds on the Week 3 hierarchy (`LibraryItem` -> `Book`/`DVD`,
`Member` -> `Student`/`Staff`). Compiled and run on JDK 21.

## What is new

| File | Change |
|---|---|
| `Loanable.java` | NEW interface: `loan(Member)`, `returnItem()` |
| `Reservable.java` | NEW interface: `reserve`, `cancelReservation`, `isReserved` |
| `LibraryItem.java` | now `implements Loanable`; `calculateLateFee()` is **abstract** (no body) |
| `Book.java` | writes its own `calculateLateFee()`; also `implements Reservable` |
| `DVD.java` | unchanged - loanable but not reservable |
| `Magazine.java` | NEW subclass; the compiler forces it to define a late fee |
| `Member.java` | now `implements Comparable<Member>` (most active first) |
| `Library.java` | `lend(Loanable, Member)`, `reserveIfPossible(...)`, `printMembersByActivity()` |

## Run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.Main
```

## Expected output

```
Added via addItem(Book): Clean Code
Added via addItem(DVD): Introduction to Algorithms
Added via addItem(LibraryItem): Software Weekly
--- Late fees if 3 day(s) late ---
Clean Code: 30.0
Introduction to Algorithms: 75.0
Software Weekly: 15.0
--- Loans ---
Clean Code loaned to Nadeesha Perera
Clean Code is already on loan.
Introduction to Algorithms loaned to Mr. Kasun Silva
Software Weekly loaned to Mr. Kasun Silva
--- Reservations ---
Clean Code reserved for Mr. Kasun Silva
Introduction to Algorithms cannot be reserved.
--- Members ranked by activity ---
Mr. Kasun Silva (2 borrowed)
Nadeesha Perera (1 borrowed)
```

## In-class experiments

1. Delete `calculateLateFee()` from `Magazine` and compile. Real error:
   `Magazine is not abstract and does not override abstract method calculateLateFee(int) in LibraryItem`
2. Add `implements Reservable` to `DVD` - the compiler demands the three methods.
3. Write a `Poster` class that implements `Loanable` but is not a `LibraryItem`; pass it to `library.lend(...)`.
4. Flip `compareTo()` so the least active member sorts first.

## Why this design

Note how `loan()` prints a message when a loan fails. Printing is a weak
way to report an error - the caller cannot react to it. Week 5
(Exception Handling) replaces these messages with real exceptions.
