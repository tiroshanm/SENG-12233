# SENG 12233 - Reference Solution: Week 11

**Lab 8 - JDBC**

SQLite via JDBC. `Database`, `ItemDAO`, `MemberDAO`, `LoanDAO` with PreparedStatement, a 3-table JOIN, FK checks, `DataAccessException`. Needs the sqlite-jdbc jar on the classpath (see the guide).

**Files that changed this week:** `dao/*`, `exception/DataAccessException`, `LibraryController`, `GuiMain`, `DaoDemo`

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp "out:lib/*" lms.DaoDemo   (then lms.GuiMain)
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
