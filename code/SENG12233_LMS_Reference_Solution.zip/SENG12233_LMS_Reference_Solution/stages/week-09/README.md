# SENG 12233 - Reference Solution: Week 9

**Lab 6 - GUI II (events, dialogs, MVC)**

ActionListeners, JOptionPane error dialogs, and the Model/View/Controller split: model = `lms.model`, view = `lms.ui`, controller = `lms.service.LibraryController`. The model no longer prints.

**Files that changed this week:** `service/LibraryController`, `ui/MainFrame`, `GuiMain`, `LibraryItem` (prints removed)

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.GuiMain
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
