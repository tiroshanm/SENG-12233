package lms;

import lms.model.*;
import lms.service.Library;
import lms.service.LibraryController;
import lms.ui.MainFrame;

import javax.swing.*;

/** Wires Model -> Controller -> View and starts the window on the EDT. */
public class GuiMain {
    public static void main(String[] args) {
        Library library = new Library();                       // MODEL
        library.addItem(new Book("B001", "Clean Code", "Robert C. Martin"));
        library.addItem(new Book("B002", "Refactoring", "Martin Fowler"));
        library.addItem(new DVD("D001", "Introduction to Algorithms", 120));
        library.addItem(new Magazine("G001", "Software Weekly", 42));
        library.addMember(new Student("M001", "Nadeesha Perera"));
        library.addMember(new Staff("M002", "Mr. Kasun Silva"));

        LibraryController controller = new LibraryController(library);   // CONTROLLER
        SwingUtilities.invokeLater(() -> new MainFrame(controller).setVisible(true));  // VIEW
    }
}
