# SENG 12233 - Reference Solution: Week 5

**Lab 4 - Exception Handling**

Custom checked `ItemNotAvailableException`, unchecked `MemberNotFoundException`, `IllegalArgumentException` for bad data. `loan()`/`returnItem()` now throw instead of printing. Returning an item frees the member's slot.

**Files that changed this week:** `exception/*`, `Loanable`, `LibraryItem`, `Library.borrowItem/returnItem/findMember/findItem`, `Main`

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.Main
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
