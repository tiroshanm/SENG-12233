# SENG 12233 - Reference Solution: Week 12

**Lab 9 - Multithreading + Final Integration**

`synchronized` Library/Controller methods, daemon `OverdueChecker`, `SwingWorker` import with a progress bar, `RaceDemo`.

**Files that changed this week:** `service/OverdueChecker`, `ui/ImportWorker`, `ui/MainFrame`, `Library`, `RaceDemo`

## Build and run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp "out:lib/*" lms.GuiMain
```

Compiled with JDK 21. This is the *reference* solution for the lab: try the lab sheet first, then compare.
