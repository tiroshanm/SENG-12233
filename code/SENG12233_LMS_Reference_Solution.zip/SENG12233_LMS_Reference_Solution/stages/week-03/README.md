# SENG 12233 — Sample Project: Week 3

**Lab 2 — Inheritance & Polymorphism (combined)**

This week covers two pillars in one lab, building on Week 2's
encapsulated `Book` and `Member`.

## Part 1 — Inheritance (new classes)

- `lms.model.LibraryItem` — new abstract parent: id, title, isBorrowed,
  `calculateLateFee()`.
- `lms.model.Book`, `lms.model.DVD` — both now `extends LibraryItem`.
  `DVD` overrides `calculateLateFee()`.
- `lms.model.Member` — now the parent of `Student` and `Staff`, which
  differ only in `maxBorrowLimit`.

## Part 2 — Polymorphism (new behaviour in `Library`)

- **`printAllLateFees(int daysLate)`** — dynamic (runtime) binding. One
  loop, but a different `calculateLateFee()` body runs per real object.
- **`addItem(LibraryItem)`, `addItem(Book)`, `addItem(DVD)`** — static
  (compile-time) binding via overloading.
- **`streamIfPossible(LibraryItem item)`** — a safe `instanceof` check
  with pattern matching, used only because streaming genuinely doesn't
  belong on every `LibraryItem`.

## To run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.Main
```

## Expected output

```
Added via addItem(Book) - extra step: logging to 'new arrivals': Clean Code
Added via addItem(Book) - extra step: logging to 'new arrivals': Effective Java
Added via addItem(DVD) - extra step: checking disc condition: Introduction to Algorithms
--- Items in the library ---
Book{id='B001', title='Clean Code', borrowed=false}
Book{id='B002', title='Effective Java', borrowed=false}
DVD{id='D001', title='Introduction to Algorithms', borrowed=false}
--- Registered members ---
Student{id='M001', name='Nadeesha Perera', borrowedCount=0, limit=3}
Staff{id='M002', name='Mr. Kasun Silva', borrowedCount=0, limit=10}
--- Late fees if 3 day(s) late ---
Clean Code: 30.0
Effective Java: 30.0
Introduction to Algorithms: 75.0
Streaming "Introduction to Algorithms" (120 min)...
Clean Code cannot be streamed - it isn't a DVD.
```

## In-class experiments (see `Main.java`'s comment for the full list)

1. Add a third item type (e.g. `Magazine`) — `printAllLateFees()` needs
   zero changes to handle it.
2. Comment out the `addItem(Book)` overload and re-run.
3. Call `streamIfPossible()` with a `Book` instead of a `DVD`.

Compiled and run successfully on JDK 21 before packaging.
