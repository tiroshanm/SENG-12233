# SENG 12233 — Sample Project: Week 2

**Lab 1 — Classes, Objects & Encapsulation**

This week is Encapsulation only. `Book`, `Member`, and `Library` are
flat classes — no inheritance yet. That arrives next week (Week 3),
when `Book` becomes a subclass of a new `LibraryItem` parent.

## Classes

- `lms.model.Book` — title, author, isbn, isBorrowed, all private, all
  validated through setters.
- `lms.model.Member` — memberId, name, borrowedCount, same pattern.
- `lms.service.Library` — holds `List<Book>` and `List<Member>`, with
  `addBook()`, `addMember()`, `listBooks()`, `listMembers()`.

## To run

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out lms.Main
```

## Expected output

```
--- Books in the library ---
Book{title='Clean Code', author='Robert C. Martin', isbn='978-0132350884', borrowed=false}
Book{title='Effective Java', author='Joshua Bloch', isbn='978-0134685991', borrowed=false}
Book{title='The Pragmatic Programmer', author='Hunt & Thomas', isbn='978-0135957059', borrowed=false}
--- Registered members ---
Member{id='M001', name='Nadeesha Perera', borrowedCount=0}
Member{id='M002', name='Kasun Silva', borrowedCount=0}
Rejected invalid book: Title cannot be blank
```

Compiled and run successfully on JDK 21 before packaging.
